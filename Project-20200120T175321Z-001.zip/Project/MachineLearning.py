# -*- coding: utf-8 -*-
import numpy as num
from sklearn import svm


#this function takes Enhao and Vanshaj's 2D array as the factors input
#the target input is an array of the next day prices for past data
#the data input will be the current day's factors
#this will return either a percent increase or a price increase or the
#   probability of the price increasing
def machinefun(factors, target, data): 
    #classifier
    model = svm.SVC(kernel='poly', gamma='auto', C=1E10)
    factors = num.array(factors)
    target = num.array(target)
    #trains the model
    #training variable and training data
    model.fit(factors, target)
    #data == testing data
    result = model.predict(data)
    #test results
    print(result)
    return

#these are the factors which Enhao and Vanshaj will input
#example: sma, macd etc
    
factors = [[1, 1], [2, 2], [3, 3], [4, 4]]
#this is the target price for the next day
target = [100, 50, -50, -100]
#this says if the WOO's are 1's, the price will have a 100% chance of 
#increasing and vice versa

#could also adjust model to predict percent increase so
#closing price is never used
test = num.array([[1, 4], [1, 1], [4, 4], [4, 3]])


machinefun(factors, target, test)